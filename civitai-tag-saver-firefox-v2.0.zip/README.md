# Civitai.red Tag Saver + Decoder — Firefox Extension (v2.0)

Combined build: Tag Saver (folders, sorting, search, scroll fix) + Tag Decoder
(numbers to English badge + 🏷️ panel + reverse search).

Same features as the Chrome v1.5 / Tampermonkey v1.5:
folders, sorting, search, collapsible sections, usage counts,
wheel-scroll isolation fix.

Storage uses the same `localStorage` keys on civitai.red, so presets
carry over from the userscript version on the same Firefox profile.

## Install (temporary, 1 minute — no signing needed for testing)

1. Download `civitai-tag-saver-firefox-v1.5.zip` below and unzip it
   somewhere permanent.
2. Open `about:debugging#/runtime/this-firefox`
3. Click **Load Temporary Add-on…**
4. Select the unzipped folder's `manifest.json`
5. Go to https://civitai.red/videos — `Tags ★` appears next to
   Everyone / Reactions / Filters.

Note: temporary add-ons are removed when Firefox closes. Re-load
with the same 3 clicks after restart.

## Permanent install (signed .xpi)

For permanent use without developer mode, the extension must be signed
by Mozilla (free):

1. Zip the contents (already done in the attached zip)
2. Submit at https://addons.mozilla.org → Submit Add-on →
   self-distribution, automated signing
3. You'll get a signed `.xpi` back — install it once, it survives restarts
   and can be shared.

If you want, I can prep the signed-ready `civitai-tag-saver-v1.5.xpi`
source zip (same files, no wrapper folder) — just ask.

## Disable the userscript version

If you also run the Tampermonkey/Violentmonkey script, disable it
first so the button doesn't load twice.

## Files

- `manifest.json` — MV2 (best compat for Firefox), runs only on civitai.red
- `content.js` — the saver (document_start, top frame only)
- `icon*.png`
