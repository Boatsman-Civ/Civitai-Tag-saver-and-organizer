# Civitai.red Tag Saver — Chrome Extension (v2.0)

Combined build: Tag Saver (folders, sorting, search, scroll fix) + Tag Decoder
(numbers to English badge + panel + reverse search).

Your existing presets carry over automatically — the extension uses the
same `localStorage` keys as the userscript on civitai.red, so no
import/export needed (but Export JSON still works as backup).

## Install (developer mode, 1 minute)

1. Download `civitai-tag-saver-extension-v1.5.zip` below and unzip it
   somewhere permanent (e.g. `Documents/civitai-tag-saver/`).
   ⚠️ Don't delete the folder afterwards — Chrome loads from it.
2. Open `chrome://extensions`
3. Turn on **Developer mode** (top-right toggle)
4. Click **Load unpacked** → select the unzipped folder
   (the one containing `manifest.json`)
5. Go to https://civitai.red/videos or /images — the `Tags ★` button
   appears next to Everyone / Reactions / Filters.

## Remove the Tampermonkey version

Running both at once loads the button twice (guarded, but messy).
Pick one:
- **Keep extension:** disable/remove the Tampermonkey script, OR
- **Keep Tampermonkey:** don't install this extension.

## Files

- `manifest.json` — MV3 manifest, runs only on civitai.red
- `content.js` — the saver (document_start, top frame only)
- `icon*.png` — toolbar icons

## Updating

Unzip the new version over the old folder, then
`chrome://extensions` → ↻ Reload on the extension.
